/*
Use app
*/
document .addEventListener ('deviceready', function () {
	riot .mount ('*');
});